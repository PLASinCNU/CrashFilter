#ifndef ladder_namespace_H
#define ladder_namespace_H

#define  ladder  psSodium_crypto_scalarmult_curve25519_sandy2x_ladder
#define _ladder _psSodium_crypto_scalarmult_curve25519_sandy2x_ladder

#endif /* ifndef ladder_namespace_H */

