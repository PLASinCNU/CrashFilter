#!/usr/bin/env bash

( source ./functions.source ; cd "$bin/.." ; make bash_tests )

# That's all Folks!
##
