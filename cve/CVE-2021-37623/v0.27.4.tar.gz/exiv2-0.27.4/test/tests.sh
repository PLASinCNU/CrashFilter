#!/usr/bin/env bash

( source ./functions.source ; cd "$bin/.." ; make tests )

# That's all Folks!
##
