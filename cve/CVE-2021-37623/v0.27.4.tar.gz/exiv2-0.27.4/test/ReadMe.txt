The test scripts in this directory are not longer in service and will be removed in Exiv2 v0.28
The functionality of the scripts in this directory is implemented in tests/bash_tests
